import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  //database
  accounts:any = {
    1000:{accno:1000,accname:"Max",accpwrd:1000,accbal:5000},
    1001:{accno:1001,accname:"Maxwell",accpwrd:1001,accbal:6000},
    1002:{accno:1002,accname:"Alan",accpwrd:1002,accbal:4000}
    
  }

  constructor() { }

  login(accno:any,accpwrd:any){
    var accs = this.accounts
    if(accno in accs){
      if(accpwrd == accs[accno]['accpwrd']){
        return true
      }else{
        return false
      }
    }else{
      return false
    }
  }


  register(accno:any,accname:any,accpwrd:any){
    var acc = this.accounts
    if(accno in acc){
      return false
    }else{
      acc[accno]={
        accno,
        accname,
        accpwrd,
        accbal:2000
      }
      return true
    }

  }
}
